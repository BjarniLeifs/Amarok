package is.ru.tictactoe;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.IOException;

import static org.junit.Assert.*;
import org.junit.Test;

public class PlayGameTest {

    @Test
    public void testMainMenu() {

	byte[] data = "0".getBytes();
	ByteArrayInputStream in = new ByteArrayInputStream(data);
	System.setIn(in);

	
	assertEquals("0", PlayGame.selectGame().tokens.get(0));
	
	System.setIn(System.in);         
       	   
    }

   
}
